﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pr_8
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void PbPaint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;


            g.FillRectangle(Brushes.Black, 0, 0, 354, 304);
            g.FillRectangle(Brushes.White, 30, 20, 2, 2);
            g.FillRectangle(Brushes.White, 80, 40, 2, 2);
            g.FillRectangle(Brushes.White, 140, 25, 2, 2);
            g.FillRectangle(Brushes.White, 200, 50, 2, 2);
            g.FillRectangle(Brushes.White, 260, 30, 2, 2);
            g.FillRectangle(Brushes.White, 320, 60, 2, 2);
            g.FillRectangle(Brushes.White, 100, 90, 2, 2);
            g.FillRectangle(Brushes.White, 250, 100, 2, 2);
            g.FillRectangle(Brushes.White, 50, 140, 2, 2);
            g.FillRectangle(Brushes.White, 300, 150, 2, 2);
            g.FillEllipse(Brushes.Blue, 20, 170, 90, 90);
            g.DrawEllipse(Pens.DarkBlue, 20, 170, 90, 90);
            g.FillEllipse(Brushes.Green, 40, 195, 30, 20);
            g.FillEllipse(Brushes.Green, 65, 215, 25, 20);
            g.FillEllipse(Brushes.Green, 45, 225, 20, 15);
            g.DrawEllipse(Pens.LightBlue, 18, 168, 94, 94);
            g.FillRectangle(Brushes.LightGray, 150, 70, 50, 150);
            g.DrawRectangle(Pens.DarkGray, 150, 70, 50, 150);
            g.FillPie(Brushes.Red, 150, 40, 50, 60, 180, 180);
            g.DrawArc(Pens.DarkRed, 150, 40, 50, 60, 180, 180);
            g.FillEllipse(Brushes.LightBlue, 165, 100, 20, 20);
            g.DrawEllipse(Pens.Black, 165, 100, 20, 20);
            g.FillEllipse(Brushes.LightBlue, 165, 135, 20, 20);
            g.DrawEllipse(Pens.Black, 165, 135, 20, 20);
            g.FillRectangle(Brushes.Red, 130, 180, 20, 40);
            g.FillRectangle(Brushes.Red, 200, 180, 20, 40);
            g.FillRectangle(Brushes.DarkGray, 160, 220, 30, 15);
            g.FillEllipse(Brushes.OrangeRed, 155, 235, 40, 45);
        }





        private void button1_Click(object sender, EventArgs e)
        {
            Graphics g = Graphics.FromHwnd(PB1.Handle);
            Close();
        }
    }
}
